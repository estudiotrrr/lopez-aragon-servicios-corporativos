<?php
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

// Correo receptor confidencial protegido en el servidor
$destinatario = 'tithor200@gmail.com';

// Sanitización de datos
$nombre   = htmlspecialchars(trim($_POST['nombre'] ?? ''));
$empresa  = htmlspecialchars(trim($_POST['empresa'] ?? ''));
$email    = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
$interes  = htmlspecialchars(trim($_POST['interes'] ?? ''));
$mensaje  = htmlspecialchars(trim($_POST['mensaje'] ?? ''));

if (empty($nombre) \vert{}\vert{} empty($email) || empty($mensaje) \vert{}\vert{} !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['error' => 'Por favor complete todos los campos obligatorios.']);
    exit;
}

// Envío seguro hacia FormSubmit desde el backend mediante cURL
$url = "https://formsubmit.co/ajax/" . urlencode($destinatario);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'Nombre'   => $nombre,
    'Empresa'  => $empresa,
    'Email'    => $email,
    'Interés'  => $interes,
    'Mensaje'  => $mensaje,
    '_subject' => "Nueva Consulta Web - $nombre ($empresa)"
]));

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode >= 200 &&$httpCode < 300) {
    echo json_encode(['success' => true]);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'No se pudo procesar el envío.']);
}